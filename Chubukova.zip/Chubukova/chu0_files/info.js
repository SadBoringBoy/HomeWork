var course_info = {
	spec:	{
		99:	{
			has_diploma:	false,
			is_vshbi:	false,
			is_ido:	false,
			is_intuit:	true,
			passed:	false,
			recorded:	false
},
		1210:	{
			has_diploma:	false,
			is_vshbi:	false,
			is_ido:	true,
			is_intuit:	false,
			passed:	false,
			recorded:	false
},
		1834:	{
			has_diploma:	false,
			is_vshbi:	true,
			is_ido:	false,
			is_intuit:	false,
			passed:	false,
			recorded:	false
}
},
	is_auth:	true,
	specall:	{
		is_vshbi:	true,
		is_ido:	true,
		is_intuit:	true,
		passed:	false,
		recorded:	false
}
};
